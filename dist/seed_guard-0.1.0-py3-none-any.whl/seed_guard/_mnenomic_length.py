from enum import Enum

class MnemonicLength(Enum):
    WORDS_12 = 12
    WORDS_24 = 24
